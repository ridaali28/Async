import React from 'react';
import { Text, Pressable, View, StyleSheet } from 'react-native';

const Welcome = ({ navigation }) => {
  return (
    <View style={styles.wrapper}>
      <Pressable
        style={styles.button}
        onPress={()=>navigation.navigate('Register')}>
        <Text style={styles.text}>Register Student</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={()=>navigation.navigate('Search')}>
        <Text style={styles.text}>Search Student</Text>
      </Pressable>
    </View>
  );
};

export default Welcome;

const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    elevation: 3,
    backgroundColor: '#2E1A47',
    margin: 10,
  },
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
});

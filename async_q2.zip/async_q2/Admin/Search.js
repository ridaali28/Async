import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  FlatList
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Search = ({ navigation }) => {
  
  const [data, setData] = useState([]);

  return (
    <View style={styles.wrapper}>
     
      <Pressable style={styles.button}>
        <Text style={styles.text}>GO</Text>
      </Pressable>
    </View>
  );
};
export default Search;

const styles = StyleSheet.create({
  box: {
    margin: 6,
    fontWeight: 500,
    width: 200,
    backgroundColor: '#0001',
    textAlign: 'center',
    height: 30,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    elevation: 3,
    backgroundColor: '#2E1A47',
    margin: 10,
  },
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
});

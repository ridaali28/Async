import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  StyleSheet,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Register = ({ navigation }) => {
  const [name, setName] = useState('');
  const [reg, setReg] = useState('');
  const [pass, setPass] = useState('');
  const [data, setData] = useState([]);

  const storeData = async () => {
    try {
      // Create an object with the input values
      //const entry = { name , reg, pass };
      const newData = [...data, name, reg, pass];
      // Update the state to include the new entry
      // setData([...data, entry]);

      // Convert the array to a JSON string
      await AsyncStorage.setItem('student_details', JSON.stringify(newData));
      setData(newData);
      alert('Data stored successfully!');
    } catch (error) {
      alert('Error storing data: ', error);
    }
  };


useEffect(() => {
    const fetchData = async () => {
      try {
        const storedData = await AsyncStorage.getItem('your_key');

        if (storedData !== null) {
          setData(JSON.parse(storedData));
        } else {
          console.log('No data found in AsyncStorage');
        }
      } catch (error) {
        console.error('Error fetching data from AsyncStorage:', error);
      }
    };

    fetchData();
  }, []);


const renderItem = ({ item }) => (
    <Text style={{ padding: 10 }}>{item}</Text>
  );

  return (
    <View style={styles.wrapper}>
      <TextInput
        style={styles.box}
        placeholder="Enter Name"
        value={name}
        onChangeText={(txt) => setName(txt.toUpperCase())}
      />

      <TextInput
        style={styles.box}
        placeholder="Enter Registration"
        value={reg}
        onChangeText={(txt) => setReg(txt.toUpperCase())}
      />

      <TextInput
        style={styles.box}
        placeholder="Enter Password"
        secureTextEntry
        value={pass}
        onChangeText={(txt) => setPass(txt)}
      />

      <Pressable style={styles.button} onPress={() => storeData()}>
        <Text style={styles.text}>GO</Text>
      </Pressable>

      {data.length > 0 ? (
        <FlatList
          data={data}
          renderItem={renderItem}
         
        />
      ) : (
        <Text>No data available</Text>
      )}
    </View>
  );
};

export default Register;

const styles = StyleSheet.create({
  box: {
    margin: 6,
    fontWeight: 500,
    width: 200,
    backgroundColor: '#0001',
    textAlign: 'center',
    height: 30,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    elevation: 3,
    backgroundColor: '#2E1A47',
    margin: 10,
  },
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
});

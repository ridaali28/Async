import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';

const AdminLogin = ({ navigation }) => {
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("123");

  const loginHnadler = () => {
    if (username === 'admin' && password === '123') { 
      navigation.navigate('Admin Panel');
    } else{
      alert("Wrong Credentials!") 
    }
  };

  return (
    <View style={styles.wrapper}>
      <TextInput
        style={styles.box}
        placeholder="Enter Username"
        value={username}
        onChangeText={(txt)=>setUsername(txt)}
      />
      <TextInput
        style={styles.box}
        placeholder="Enter Password"
        secureTextEntry
        value={password}
        onChangeText={(txt)=>setPassword(txt)}
      />

      <Pressable style={styles.button} onPress={()=>loginHnadler()}>
        <Text style={styles.text}>GO</Text>
      </Pressable>
    </View>
  );
};

export default AdminLogin;

const styles = StyleSheet.create({
  box: {
    margin: 6,
    fontWeight: 500,
    width: 200,
    backgroundColor: '#0001',
    textAlign: 'center',
    height: 30,
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    elevation: 3,
    backgroundColor: '#2E1A47',
    margin: 10,
  },
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
});

import React from 'react';
import { Text, Pressable, View, StyleSheet } from 'react-native';

const Welcome = ({ navigation }) => {
  return (
    <View style={styles.wrapper}>
      
      <Pressable
      onPress={()=> navigation.navigate("Admin Login")}
      style={styles.button}
      >
        <Text style={styles.text}>Admin Panel</Text>
      </Pressable>

       <Pressable
      onPress={()=> navigation.navigate("Student Login")}
      style={styles.button}
      >
        <Text style={styles.text}>Student Panel</Text>
      </Pressable>
    </View>
  );
};

export default Welcome;

const styles = StyleSheet.create({
 
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 4,
    elevation: 3,
    backgroundColor: '#2E1A47',
    margin: 10,
  },
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: 'white',
  },
});
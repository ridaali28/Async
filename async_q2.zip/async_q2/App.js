import * as React from 'react';
import { Button, View, Text } from 'react-native';
import AdminLogin from './Admin/AdminLogin';
import Welcome from './Welcome';
import StudentLogin from './Student/StudentLogin';
import AdminPanel from './Admin/AdminPanel';
import Register from './Admin/Register';
import Search from './Admin/Search';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Welcome" component={Welcome} />
        <Stack.Screen name="Admin Login" component={AdminLogin} />
        <Stack.Screen name="Admin Panel" component={AdminPanel} />
        <Stack.Screen name="Student Login" component={StudentLogin} />
         <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="Search" component={Search} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;

import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';

const StudentLogin = () => {
  const [reg, setReg] = useState('');
  const [password, setPassword] = useState('');

  return (
    <View style={styles.wrapper}>
      <TextInput
        style={styles.box}
        placeholder="Enter Registration"
        onChangeText={(txt) => setReg(txt)}
      />
      <TextInput
        style={styles.box}
        placeholder="Enter Password"
        onChangeText={(txt) => setPassword(txt)}
      />
    </View>
  );
};

export default StudentLogin;

const styles = StyleSheet.create({
  box: {
    margin: 6,
    fontWeight: 500,
    width: 200,
    backgroundColor: '#0001',
    textAlign: 'center',
    height: 30,
  },
 
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  }
});
